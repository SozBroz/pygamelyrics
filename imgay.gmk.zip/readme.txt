readme

a to proceed (after a turn is over)

can use 0-6 keys to set counter to a stage in first stage

in second stage can only run, use 6 to restart this stage, 

f5 to restart the """""""game"""""""""
theres only one sound effect that plays when you get hit, I play muted: don't play with high volume.


I want to make the first stage have 2 more attacks, gib ideas

